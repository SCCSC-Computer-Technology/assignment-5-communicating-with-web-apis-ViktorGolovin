using CPT_206_Lab_5_Viktor_Golovin.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;


namespace CPT_206_Lab_5_Viktor_Golovin.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory clientFactory;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public HomeController(
        ILogger<HomeController> logger,
        StudentProfileContext injectedContext,
        IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            db = injectedContext;
            clientFactory = httpClientFactory;
        }
        public async Task<IActionResult> studentProfile(long id)
        {
            string uri;
            if (string.IsNullOrEmpty(id))
            {
                ViewData["Title"] = "All Student Profiles";
                uri = "api/students/";
            }
            else
            {
                ViewData["Title"] = $"Student id {studentProfile}";
                uri = $"api/studentProfile/?id={StudentProfile}";
            }
            HttpClient client = clientFactory.CreateClient(
              name: "StudentProfile.WebApi");
            HttpRequestMessage request = new(
              method: HttpMethod.Get, requestUri: uri);
            HttpResponseMessage response = await client.SendAsync(request);
            IEnumerable<studentProfile>? model = await response.Content
              .ReadFromJsonAsync<IEnumerable<studentProfile>>();
            return View(model);
        }

    }
}
